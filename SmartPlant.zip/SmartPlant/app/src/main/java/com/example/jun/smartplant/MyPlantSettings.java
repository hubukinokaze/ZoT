package com.example.jun.smartplant;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class MyPlantSettings extends ActionBarActivity {
    private SharedPreferences.Editor editor;

    private String nameOfPlant;
    private String username;
    private HashMap<String, List<String>> listOfPlantSettings;

    private Switch notifySwitch;
    private boolean notifySwitchOn;
    private String notify;

    private Button notify_question;
    private Button saveButton;

    private String notify_message;

    private HashMap<String, List<String>> listOfAccountSettings;

    // Creating JSON Parser object
    JSONParser jsonParser = new JSONParser();

    // url to update settings
    private static String URL_update_setting = "http://default-environment-nk2mjs3aen.elasticbeanstalk.com/update_settings.php";

    // JSON Node names
    private static final String TAG_USERNAME = "username";
    private static final String TAG_FLOWER = "flower";
    private static final String TAG_NOTIFY = "notify";

    // moisture JSONArray
    JSONArray logs = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_plant_settings);
        getSupportActionBar().setTitle("Plant Settings");

        //retrieve the name of the plant for the settings page
        Bundle extras = getIntent().getExtras();
        nameOfPlant = extras.getString("Name");
        username = extras.getString("Username");
        listOfPlantSettings = (HashMap<String, List<String>>)extras.getSerializable("listOfPlantSettings");
        ((TextView) findViewById(R.id.text_plantName)).setText(nameOfPlant);

//        setupMoisture();
        setupSwitches();

        notify_question = (Button) findViewById(R.id.notify_button);
        notify_question.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notify_message = getResources().getString(R.string.notify_message);
                Toast.makeText(getApplicationContext(), notify_message, Toast.LENGTH_LONG).show();
            }
        });

        //A save settings button
        saveButton = (Button) findViewById(R.id.save_button);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //checks if the notify switch is toggled on/off
                notifySwitchOn = notifySwitch.isChecked();
                editor.putBoolean("notify", notifySwitchOn);
                new SaveSettings().execute();
                Toast.makeText(getApplicationContext(), "Saved settings.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupSwitches() {
        //set up the two switches
        notifySwitch = (Switch) findViewById(R.id.notify_Switch);
        if (String.valueOf(listOfPlantSettings.get(nameOfPlant).get(0)).equals("0")) {
            notifySwitchOn = false;
            notifySwitch.setChecked(notifySwitchOn);
        } else {
            notifySwitchOn = true;
            notifySwitch.setChecked(notifySwitchOn);
        }
    }

    public void onPause(){
        super.onPause();
    }

    public void onResume(){
        super.onResume();
    }

    public boolean getNotifyValue(){
        return notifySwitchOn;
    }


    /**
     * Background Async Task to  Save settings
     * */
    class SaveSettings extends AsyncTask<String, String, String> {
        /**
         * Saving settings
         * */
        protected String doInBackground(String... args) {

            //getting updated data
            //work in progress
            if ("true".equals(String.valueOf(notifySwitchOn))){notify = "1";}else{notify = "0";}

            // Building Parameters
            List<NameValuePair> params = new ArrayList<>();
            params.add(new BasicNameValuePair(TAG_USERNAME, username));
            params.add(new BasicNameValuePair(TAG_FLOWER, nameOfPlant));
            params.add(new BasicNameValuePair(TAG_NOTIFY, notify));

            // sending modified data through http request
            // Notice that update setting url accepts POST method
            jsonParser.makeHttpRequest(URL_update_setting, "POST", params);

            return null;
        }
    }
}
