package com.example.jun.smartplant;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Dashboard extends ActionBarActivity {
    private ArrayList<String> emptyList = new ArrayList<String>();
    private MyCustomAdapter adapter;
    private ListView list;
    private Button addPlants;
    private String plantEntryName;
    private String username;
    private HashMap<String, List<String>> listOfPlantSettings = new HashMap<String, List<String>>();

    // Creating JSON Parser object
    JSONParser jsonParser = new JSONParser();

    // url to create settings
    private static String URL_new_setting = "http://default-environment-nk2mjs3aen.elasticbeanstalk.com/insert_settings_into_db.php";
    // url to get all settings list
    private static String URL_settings_data = "http://default-environment-nk2mjs3aen.elasticbeanstalk.com/retrieve_settings.php";

    private static String URL_username_plant = "http://default-environment-nk2mjs3aen.elasticbeanstalk.com/insert_current_plant.php";

    // JSON Node names
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_ARRAY = "settings";
    private static final String TAG_USERNAME = "username";
    private static final String TAG_FLOWER = "flower";
    private static final String TAG_NOTIFY = "notify";

    // moisture JSONArray
    JSONArray logs = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        new LoadAllSettings().execute();

        //retrieve the username
        Bundle extras = getIntent().getExtras();
        username = extras.getString("Username");

        list = (ListView) findViewById(R.id.plantList);

        adapter = new MyCustomAdapter(Dashboard.this, R.layout.list_of_plants, R.id.list_item_string, emptyList, username, listOfPlantSettings);
        list.setAdapter(adapter);



        //A button that will add plants to the list
        addPlants = (Button) findViewById(R.id.button_add_plant);
        addPlants.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmName();
            }
        });


    }

    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_dashboard, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item){
        //handle presses on the action bar
        switch (item.getItemId()){
            case R.id.refresh_settings:
                Toast.makeText(getApplicationContext(), R.string.info_button, Toast.LENGTH_LONG).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void onPause(){
        super.onPause();
    }

    public void onResume(){
        super.onResume();
    }

    private void confirmName() {
        AlertDialog.Builder alert = new AlertDialog.Builder(this);

        alert.setTitle("Plant Name");
        alert.setMessage("Please enter the name of the plant entry.");

        // Set an EditText view to get user input
        final EditText input = new EditText(this);
        //prevents user from entering multiple lines for a plant name
        input.setSingleLine();
        //display the user interface for typing in the name
        alert.setView(input);

        //if the user presses the OK button
        alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                try {
                    //Grab the name the user enters
                    plantEntryName = input.getText().toString().toLowerCase();
                    plantEntryName = plantEntryName.substring(0, 1).toUpperCase() + plantEntryName.substring(1);
                    //check to see if there is a plant with that name already
                    if (!adapter.getList().containsKey(plantEntryName)) {
                        adapter.addNewPlant(plantEntryName);

                        new CreateNewSetting().execute();
                        new SendUsernamePlant().execute();

                        Toast.makeText(getApplicationContext(), "Your plant has been added.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Sorry, that name is already used.", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Please enter a valid name.", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }

            }
        });

        //if the user presses the cancel button
        alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        });
        alert.show();
    }


    /**
     * Background Async Task to Load all data by making HTTP Request
     */
    class LoadAllSettings extends AsyncTask<String, String, String> {
        /**
         * getting All products from url
         */
        protected String doInBackground(String... args) {
            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            // getting JSON string from URL
            JSONObject json = jsonParser.makeHttpRequest(URL_settings_data, "GET", params);

            try {
                // Checking for SUCCESS TAG
                int success = json.getInt(TAG_SUCCESS);

                if (success == 1) {
                    // logs found
                    // Getting Array of Logs
                    logs = json.getJSONArray(TAG_ARRAY);

                    // looping through All Products
                    for (int i = 0; i < logs.length(); i++) {
                        JSONObject c = logs.getJSONObject(i);

                        // Storing each json item in variable
                        if (username.equals(c.getString(TAG_USERNAME))) {

                            String flower = c.getString(TAG_FLOWER);

                            ArrayList temp = new ArrayList<String>();
                            temp.add(c.getString(TAG_NOTIFY));

                            listOfPlantSettings.put(flower, temp);
                            emptyList.add(flower);
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    /**
     * Background Async Task to Create new setting
     */
    class CreateNewSetting extends AsyncTask<String, String, String> {
        /**
         * Creating setting
         */
        protected String doInBackground(String... args) {
            // Building Parameters
            List<NameValuePair> params = new ArrayList<>();
            params.add(new BasicNameValuePair(TAG_USERNAME, username));
            params.add(new BasicNameValuePair(TAG_FLOWER, plantEntryName));
            params.add(new BasicNameValuePair(TAG_NOTIFY, "0"));

            listOfPlantSettings.put(plantEntryName, new ArrayList<String>() {{
                add("0");
            }});

            // getting JSON Object
            jsonParser.makeHttpRequest(URL_new_setting, "POST", params);
            return null;
        }
    }

    /**
     * Background Async Task to upload settings to txt
     */
    class SendUsernamePlant extends AsyncTask<String, String, String> {
        protected String doInBackground(String... args) {
            DefaultHttpClient client = new DefaultHttpClient();
            plantEntryName = plantEntryName.trim();
            HttpPost post;
            if (plantEntryName.contains(" ")){
                String plantName = "";
                String[] name_split = plantEntryName.split(" ");
                for (int i =0; i < name_split.length; i++){
                    plantName += name_split[i];
                }
                post = new HttpPost(URL_username_plant+"?username="+username+"&flower="+plantName);//output is the variable you used in your program
            }else {
                post = new HttpPost(URL_username_plant + "?username=" + username + "&flower=" + plantEntryName);//output is the variable you used in your program
            }

            try {
                client.execute(post);
            }catch (ClientProtocolException e) {
                e.printStackTrace();
            }catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
