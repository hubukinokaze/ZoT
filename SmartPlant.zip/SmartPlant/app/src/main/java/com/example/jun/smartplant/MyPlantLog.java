package com.example.jun.smartplant;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ExpandableListView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class MyPlantLog extends ActionBarActivity {
    private ExpandableListAdapter listAdapter;
    private ExpandableListView listView;

//    private SharedPreferences.Editor editor;
    protected String username;
    protected String flower;
//    protected boolean isNotifiedOn;


    private List<String> listDataHeader;
    private HashMap<String, List<String>> listDataChild;
    protected HashMap<String, List<String>> listOfPlantSettings;

    List<String> January = new ArrayList<>();
    List<String> February = new ArrayList<>();
    List<String> March = new ArrayList<>();
    List<String> April = new ArrayList<>();
    List<String> May = new ArrayList<>();
    List<String> June = new ArrayList<>();
    List<String> July = new ArrayList<>();
    List<String> August = new ArrayList<>();
    List<String> September = new ArrayList<>();
    List<String> October = new ArrayList<>();
    List<String> November = new ArrayList<>();
    List<String> December = new ArrayList<>();

    // Creating JSON Parser object
    JSONParser jsonParser = new JSONParser();

    // url to get all products list
    private static String URL_moisture_data;
    // url to get all settings list
    private static String URL_settings_data;

    static {
        URL_settings_data = "http://default-environment-nk2mjs3aen.elasticbeanstalk.com/retrieve_settings.php";
        URL_moisture_data = "http://default-environment-nk2mjs3aen.elasticbeanstalk.com/retrieve_moisture_data.php";
    }

    // JSON Node names
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_ARRAY = "moisture_levels";
    private static final String TAG_DATE = "date";
    private static final String TAG_TIME = "time";
    private static final String TAG_MOISTURE_LEVEL = "moisture_level";
    private static final String TAG_WATERED = "watered";
    private static final String TAG_USERNAME = "username";
    private static final String TAG_FLOWER = "flower";
    private static final String TAG_NOTIFY = "notify";

    private NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("Smart Irrigation Notification")
            .setContentText("Your plant has been watered!");

    // moisture JSONArray
    JSONArray logs = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_plant_log);
        getSupportActionBar().setTitle("Plant Log");

        Bundle extras = getIntent().getExtras();
        try {
            flower = extras.getString("Name");
            username = extras.getString("Username");
            listOfPlantSettings = (HashMap<String, List<String>>) extras.getSerializable("listOfPlantSettings");
        } catch (Exception e){
            Log.d("error","exception");
        }

        //get the list view
        listView = (ExpandableListView) findViewById(R.id.expandableListView);

        // preparing list data...
        prepareListDataHeaders();
        //prepareListData();

        listAdapter = new ExpandableListAdapter(this, listDataHeader, listDataChild);

        // setting list adapter
        listView.setAdapter(listAdapter);

        setupNotifications();

        // Loading stuff in Background Thread
        new LoadAllSettings().execute();
        new LoadAllLogs().execute();

    }

    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_my_plant_log, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item){
        //handle presses on the action bar
        switch (item.getItemId()){
            case R.id.refresh_levels:
                new RefreshAllLogs().execute();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

//    private void setupSwitches() {
//        //set up the two switches
//        isNotifiedOn = editor.getBoolean
//    }

    public void setupNotifications(){
        //set the screen user will navigate to when notification is clicked
        Intent resultIntent = new Intent(this, MyPlantLog.class);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        mBuilder.setContentIntent(pendingIntent);
    }

    public void issueNotification(){
        int mNotificationId = 1;
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notificationManager.notify(mNotificationId, mBuilder.build());
    }

    private void prepareListDataHeaders(){
        listDataHeader = new ArrayList<>();
        listDataChild = new HashMap<>();
        // adding child data
        listDataHeader.add("January");
        listDataHeader.add("February");
        listDataHeader.add("March");
        listDataHeader.add("April");
        listDataHeader.add("May");
        listDataHeader.add("June");
        listDataHeader.add("July");
        listDataHeader.add("August");
        listDataHeader.add("September");
        listDataHeader.add("October");
        listDataHeader.add("November");
        listDataHeader.add("December");
    }

    private void prepareListData(String all_info, String date){
        if (date.startsWith("01")){January.add(all_info);}
        else if (date.startsWith("02")){February.add(all_info);}
        else if (date.startsWith("03")){March.add(all_info);}
        else if (date.startsWith("04")){April.add(all_info);}
        else if (date.startsWith("05")){May.add(all_info); }
        else if (date.startsWith("06")){June.add(all_info); }
        else if (date.startsWith("07")){July.add(all_info); }
        else if (date.startsWith("08")){August.add(all_info); }
        else if (date.startsWith("09")){September.add(all_info); }
        else if (date.startsWith("10")){October.add(all_info); }
        else if (date.startsWith("11")){November.add(all_info); }
        else if (date.startsWith("12")){December.add(all_info); }

        listDataChild.put(listDataHeader.get(0), January);
        listDataChild.put(listDataHeader.get(1), February);
        listDataChild.put(listDataHeader.get(2), March);
        listDataChild.put(listDataHeader.get(3), April);
        listDataChild.put(listDataHeader.get(4), May);
        listDataChild.put(listDataHeader.get(5), June);
        listDataChild.put(listDataHeader.get(6), July);
        listDataChild.put(listDataHeader.get(7), August);
        listDataChild.put(listDataHeader.get(8), September);
        listDataChild.put(listDataHeader.get(9), October);
        listDataChild.put(listDataHeader.get(10), November);
        listDataChild.put(listDataHeader.get(11), December);
    }

    private void prepareRefreshedListData(String all_info, String date){
        // adding child data
        if (date.startsWith("01")){January.add(all_info);}
        else if (date.startsWith("02")){ February.add(all_info);}
        else if (date.startsWith("03")){ March.add(all_info);}
        else if (date.startsWith("04")){ April.add(all_info);}
        else if (date.startsWith("04")){ May.add(all_info);}
        else if (date.startsWith("04")){ June.add(all_info);}
        else if (date.startsWith("04")){ July.add(all_info);}
        else if (date.startsWith("04")){ August.add(all_info);}
        else if (date.startsWith("04")){ September.add(all_info);}
        else if (date.startsWith("04")){ October.add(all_info);}
        else if (date.startsWith("04")){ November.add(all_info);}
        else if (date.startsWith("04")){ December.add(all_info);}


        listDataChild.put(listDataHeader.get(0), January);
        listDataChild.put(listDataHeader.get(1), February);
        listDataChild.put(listDataHeader.get(2), March);
        listDataChild.put(listDataHeader.get(3), April);
        listDataChild.put(listDataHeader.get(4), May);
        listDataChild.put(listDataHeader.get(5), June);
        listDataChild.put(listDataHeader.get(6), July);
        listDataChild.put(listDataHeader.get(7), August);
        listDataChild.put(listDataHeader.get(8), September);
        listDataChild.put(listDataHeader.get(9), October);
        listDataChild.put(listDataHeader.get(10), November);
        listDataChild.put(listDataHeader.get(11), December);
    }

    private void clearAllMonths(){
        January.clear();
        February.clear();
        March.clear();
        April.clear();
        May.clear();
        June.clear();
        July.clear();
        August.clear();
        September.clear();
        October.clear();
        November.clear();
        December.clear();
    }


    public boolean compareData(JSONArray logs, String date){
        if (date.startsWith("01")){return logs.length() == January.size();}
        else if (date.startsWith("02")){return logs.length() == February.size();}
        else if (date.startsWith("03")){return logs.length() == March.size();}
        else if (date.startsWith("04")){return logs.length() == April.size();}
        else if (date.startsWith("05")){return logs.length() == May.size();}
        else if (date.startsWith("06")){return logs.length() == June.size();}
        else if (date.startsWith("07")){return logs.length() == July.size();}
        else if (date.startsWith("08")){return logs.length() == August.size();}
        else if (date.startsWith("09")){return logs.length() == September.size();}
        else if (date.startsWith("10")){return logs.length() == October.size();}
        else if (date.startsWith("11")){return logs.length() == November.size();}
        else if (date.startsWith("12")){return logs.length() == December.size();}
        return false;
    }


    /**
     * Background Async Task to Load all data by making HTTP Request
     * */
    class LoadAllLogs extends AsyncTask<String, String, String> {
        /**
         * getting All moisture levels from MySQL
         * */

        protected String doInBackground(String... args) {
            // Building Parameters
            List<NameValuePair> params = new ArrayList<>();
            // getting JSON string from URL
            JSONObject json = jsonParser.makeHttpRequest(URL_moisture_data, "GET", params);

            try {
                // Checking for SUCCESS TAG
                int success = json.getInt(TAG_SUCCESS);
                if (success == 1) {
                    // logs found
                    // Getting Array of Logs
                    logs = json.getJSONArray(TAG_ARRAY);
                    Log.d("logs", ""+logs);

                    // looping through All Products
                    for (int i = 0; i < logs.length(); i++) {
                        JSONObject c = logs.getJSONObject(i);
                        // Storing each json item in variable
                        String date = c.getString(TAG_DATE);
                        String time = c.getString(TAG_TIME);
                        String moistureLevel = c.getString(TAG_MOISTURE_LEVEL);
                        String watered = c.getString(TAG_WATERED);
                        String user = c.getString(TAG_USERNAME);
                        String flow = c.getString(TAG_FLOWER);

                        if (user.equals(username) && flow.equals(flower)){
                            //put all information for log into one string
                            String all_info = date + "," + time + "," + moistureLevel;

                            if (watered.equals("1")){
                                issueNotification();
                            }
                            prepareListData(all_info, date.substring(0, 2));

                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(String file_url) {
            // updating UI from Background Thread
            runOnUiThread(new Runnable() {
                public void run() {
                    /**
                     * Updating parsed JSON data into ListView
                     * */
                    listAdapter = new ExpandableListAdapter(MyPlantLog.this, listDataHeader, listDataChild);

                    // updating listview
                    listView.setAdapter(listAdapter);
                    Toast.makeText(getApplicationContext(), "Data loaded", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }


    class RefreshAllLogs extends AsyncTask<String,String,String>{

        protected void onPreExecute(){
            Toast.makeText(getApplicationContext(), "Loading moisture data...", Toast.LENGTH_SHORT).show();
        }

        protected String doInBackground(String... args){
            // Building Parameters
            List<NameValuePair> params = new ArrayList<>();
            // getting JSON string from URL
            JSONObject json = jsonParser.makeHttpRequest(URL_moisture_data, "GET", params);

            try {
                // Checking for SUCCESS TAG
                int success = json.getInt(TAG_SUCCESS);
                if (success == 1) {
                    // logs found
                    // Getting Array of Logs
                    logs = json.getJSONArray(TAG_ARRAY);

                    //extract the first date from the json object
                    JSONObject obj = logs.getJSONObject(0);
                    String dateToCheck = obj.getString(TAG_DATE);

                    //pass logs and dateToCheck into function compareData
                    boolean sameData = compareData(logs, dateToCheck);

                    if (!sameData){
                        //data has changed, delete old data and load new data

                        clearAllMonths();

                        // load new data
                        for (int i = 0; i < logs.length(); i++) {
                            JSONObject c = logs.getJSONObject(i);

                            // Storing each json item in variable
                            String date = c.getString(TAG_DATE);
                            String time = c.getString(TAG_TIME);
                            String moisture = c.getString(TAG_MOISTURE_LEVEL);
                            String watered = c.getString(TAG_WATERED);
                            String user = c.getString(TAG_USERNAME);
                            String flow = c.getString(TAG_FLOWER);

                            if (user.equals(username) && flow.equals(flower)) {
                                String all_info = date + "," + time + "," + moisture;

                                if (watered.equals("1")) {
                                    issueNotification();
                                }
                                prepareRefreshedListData(all_info, date.substring(0, 2));
                            }
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(String file_url){
            // updating UI from Background Thread
            runOnUiThread(new Runnable() {
                public void run() {
                    /**
                     * Updating parsed JSON data into ListView
                     * */
                    listAdapter = new ExpandableListAdapter(MyPlantLog.this, listDataHeader, listDataChild);

                    // updating listview
                    listView.setAdapter(listAdapter);
                    Toast.makeText(getApplicationContext(), "Data loaded", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    /**
     * Background Async Task to Load all data by making HTTP Request
     */
    class LoadAllSettings extends AsyncTask<String, String, String> {
        /**
         * getting All products from url
         */
        protected String doInBackground(String... args) {
            // Building Parameters
            List<NameValuePair> params = new ArrayList<>();
            // getting JSON string from URL
            JSONObject json = jsonParser.makeHttpRequest(URL_settings_data, "GET", params);

            try {
                // Checking for SUCCESS TAG
                int success = json.getInt(TAG_SUCCESS);

                if (success == 1) {
                    // logs found
                    // Getting Array of Logs
                    logs = json.getJSONArray(TAG_ARRAY);

                    // looping through All Products
                    for (int i = 0; i < logs.length(); i++) {
                        JSONObject c = logs.getJSONObject(i);

                        // Storing each json item in variable
                        if (username.equals(c.getString(TAG_USERNAME))) {

                            flower = c.getString(TAG_FLOWER);

                            ArrayList temp = new ArrayList<String>();
                            temp.add(c.getString(TAG_NOTIFY));

                            listOfPlantSettings.put(flower, temp);
                        }
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }


}
