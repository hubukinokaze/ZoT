package com.example.jun.smartplant;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Jun on 2/10/2015.
 */
public class MyCustomAdapter extends ArrayAdapter<String> {
    private ArrayList<String> list = new ArrayList<String>();
    private Context context;
    private String username;
    private String plantEntryName;
    private HashMap<String, List<String>> listOfPlantSettings;

    // Creating JSON Parser object
    JSONParser jsonParser = new JSONParser();

    // url to delete a setting
    private static String URL_delete_setting = "http://default-environment-nk2mjs3aen.elasticbeanstalk.com/delete_settings.php";


    // JSON Node names
    private static final String TAG_USERNAME = "username";
    private static final String TAG_FLOWER = "flower";

    public MyCustomAdapter(Context context, int textViewResourceId1, int textViewResourceId2, ArrayList<String> list, String Username, HashMap<String, List<String>> listofplantsettings) {
        super(context, textViewResourceId1, textViewResourceId2,  list);
        this.context = context;
        this.list = list;
        username = Username;
        listOfPlantSettings = listofplantsettings;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.list_of_plants, null);
        }

        //Handle TextView and display string from your list
        final TextView listItemText = (TextView) view.findViewById(R.id.list_item_string);
        plantEntryName = list.get(position).toString();
        listItemText.setText(plantEntryName);

        //Handle buttons and add onClickListeners
        Button deleteButton = (Button) view.findViewById(R.id.buttonDeletePlant);
        Button settingsButton = (Button) view.findViewById(R.id.button_my_plant);
        Button myPlantLogButton = (Button) view.findViewById(R.id.button_my_plant_log);

        listItemText.setSelected(true);
        deleteButton.setSelected(true);
        settingsButton.setSelected(true);

        //Adds a delete button next to the plant name
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //removes the plant from the database
                new DeleteSetting().execute();
                //notify user the plant has been removed
                Toast.makeText(context, plantEntryName + " has been removed from " + username + "'s account.", Toast.LENGTH_SHORT).show();
                //removes the plant from the list
                list.remove(position);
                //Update view
                notifyDataSetChanged();
            }
        });
        //Adds a Settings button that will take you to the plant settings page
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Go to the plant settings page
                Intent intent = new Intent(context, MyPlantSettings.class);
                intent.putExtra("Name", list.get(position).toString());
                intent.putExtra("Username", username);
                intent.putExtra("listOfPlantSettings", listOfPlantSettings);
                context.startActivity(intent);
            }
        });
        //Adds a My Plant Log button that will take you to the plant's log history page
        myPlantLogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, MyPlantLog.class);
                intent.putExtra("Name", list.get(position).toString());
                intent.putExtra("Username", username);
                intent.putExtra("listOfPlantSettings", listOfPlantSettings);
                context.startActivity(intent);
            }
        });
        return view;
    }
    public HashMap getList() {
        return listOfPlantSettings;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    //Add plant button at the bottom of the screen
    public void addNewPlant(String name) {
        //Add the plant to the list of plants
        list.add(name);
        //Update view
        notifyDataSetChanged();
    }

    /**
     * Background Async Task to delete setting
     */
    class DeleteSetting extends AsyncTask<String, String, String> {
        protected String doInBackground(String... args) {
            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair(TAG_USERNAME, username));
            params.add(new BasicNameValuePair(TAG_FLOWER, plantEntryName));

            // getting JSON Object
            jsonParser.makeHttpRequest(URL_delete_setting, "POST", params);
            return null;
        }
    }



}
