package com.example.jun.smartplant;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Login extends ActionBarActivity {
    JSONParser jsonParser = new JSONParser();
    public EditText username;
    public EditText password;
    private Button buttonLogin;
    private Button buttonRegister;

    //save data for login information
    private String USERNAME;
    private String PASSWORD;

    private HashMap<String, String> usernamesAndPasswords = new HashMap<String, String>();

    // url to create new account
    private static String URL_new_account = "http://default-environment-nk2mjs3aen.elasticbeanstalk.com/insert_account_into_db.php";
    // url to retrieve accounts
    private static String URL_account_data = "http://default-environment-nk2mjs3aen.elasticbeanstalk.com/retrieve_accounts.php";

    // JSON Node names
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_ARRAY = "accounts";
    private static final String TAG_USERNAME = "username";
    private static final String TAG_PASSWORD = "password";

    // moisture JSONArray
    JSONArray logs = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();

        new LoadAllAccounts().execute();

        //grab the users input for username and password
        username = (EditText) findViewById(R.id.input_username);
        password = (EditText) findViewById(R.id.input_password);

        //setup the login button
        buttonLogin = (Button) findViewById(R.id.button_login);
        //listen for the login button to be pressed and verify
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //grab the username and password into strings
                setUserAndPW();
                try {
                    if (!isNull(USERNAME, PASSWORD)) {
                        if (validate(USERNAME, PASSWORD)) {
                            Intent intent = new Intent(v.getContext(), Dashboard.class);
                            intent.putExtra("Username", USERNAME);
                            startActivityForResult(intent, 0);
                        } else {
                            Toast.makeText(getApplicationContext(), "The username or password is incorrect, try again.", Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "That username is not registered yet, try registering.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //create a register button
        buttonRegister = (Button) findViewById(R.id.button_register);
        //listen for the register button to be pressed and add the user and password to hashmap
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //grab the username and password into strings
                setUserAndPW();
                try {
                    if (!isNull(USERNAME, PASSWORD)) {
                        //if user/pass combo is in hashmap, alert that they already registered
                        if (usernamesAndPasswords.containsKey(USERNAME)) {
                            Toast.makeText(getApplicationContext(), "Account with username exists.", Toast.LENGTH_SHORT).show();
                        }

                        // if user/pass combo is NOT in hashmap, add it
                        if (!usernamesAndPasswords.containsKey(USERNAME)) {
                            usernamesAndPasswords.put(USERNAME, PASSWORD);
                            new CreateNewAccount().execute();
                            Toast.makeText(getApplicationContext(), "Account Registered!", Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_login, menu);
        return super.onCreateOptionsMenu(menu);
    }

    private boolean validate(String username, String password) {
        if (usernamesAndPasswords.get(username).equals(password)) return true;
        return false;
    }

    private boolean isNull(String username, String password) {
        //if the username is empty...
        if (username.equals("") || password.equals("")) {
            Toast.makeText(getApplicationContext(), "Username and/or password can't be empty.", Toast.LENGTH_SHORT).show();
            return true;
            //if the password is empty or less than 6 characters...
        } else if (password.length() < 6) {
            Toast.makeText(getApplicationContext(), "Password must be at least 6 characters long.", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    private void createListOfAccounts(String username, String password) {

    }

    private void setUserAndPW() {
        USERNAME = username.getText().toString();
        PASSWORD = password.getText().toString();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        android.os.Debug.stopMethodTracing();
        finish();
    }

    /**
     * Background Async Task to Load all account data by making HTTP Request
     * */
    class LoadAllAccounts extends AsyncTask<String, String, String> {
        /**
         * getting All products from url
         * */
        protected String doInBackground(String... args) {
            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            // getting JSON string from URL
            JSONObject json = jsonParser.makeHttpRequest(URL_account_data, "GET", params);

            try {
                // Checking for SUCCESS TAG
                int success = json.getInt(TAG_SUCCESS);
                if (success == 1) {
                    // logs found
                    // Getting Array of Logs
                    logs = json.getJSONArray(TAG_ARRAY);

                    // looping through All Products
                    for (int i = 0; i < logs.length(); i++) {
                        JSONObject c = logs.getJSONObject(i);

                        // Storing each json item in list
                        usernamesAndPasswords.put(c.getString(TAG_USERNAME), c.getString(TAG_PASSWORD));
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (RuntimeException re){
                re.printStackTrace();
            }
            return null;
        }
    }

    /**
     * Background Async Task to Create new account
     */
    class CreateNewAccount extends AsyncTask<String, String, String> {
        /**
         * Creating product
         */
        protected String doInBackground(String... args) {
            // Building Parameters
            List<NameValuePair> params = new ArrayList<NameValuePair>();
            params.add(new BasicNameValuePair("username", USERNAME));
            params.add(new BasicNameValuePair("password", PASSWORD));

            // getting JSON Object
            // Note that create product url accepts POST method
            jsonParser.makeHttpRequest(URL_new_account, "POST", params);
            return null;
        }
    }
}
