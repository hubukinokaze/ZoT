<?php

/*
* All database connection variables
*/

define('DB_USER', "alfonsoaranzazu"); //db user
define('DB_PASSWORD', "Broncos7"); //db password(mention your db password here)
define('DB_DATABASE', "informatics117db"); //database name
define('DB_SERVER', "informatics117.cjtlenhgjvw5.us-west-1.rds.amazonaws.com:3306"); //db server

?>